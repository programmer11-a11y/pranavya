// tailwind.config.js
module.exports = {
    theme: {
    },
  };
  